DACH Digitalwerk - BFSG 2026 Turnkey Compliance Kit v1.0
=========================================================
1. Binden Sie `bfsg-a11y-widget.min.js` vor dem schlie?enden </body>-Tag Ihrer Website ein:
   <script src="/pfad/zu/bfsg-a11y-widget.min.js" defer></script>
2. Versehen Sie Ihren Hauptinhalt mit der ID `main-content`:
   <main id="main-content">...</main>
3. Erstellen Sie Ihre rechtssichere Barrierefreiheitserkl?rung nach ? 14 BFSG unter:
   https://dachdigitalwerk.github.io/bfsg-barrierefreiheit-audit-generator/
